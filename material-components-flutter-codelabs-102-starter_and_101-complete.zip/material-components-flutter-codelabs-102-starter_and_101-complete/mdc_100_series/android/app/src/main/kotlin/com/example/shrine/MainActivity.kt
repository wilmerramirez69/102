package com.example.shrine

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
